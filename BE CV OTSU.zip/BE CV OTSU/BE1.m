%%  Question 1 :  
%  Display a grayscale image and a color image
clear all;
clc;
Cargo_Color = imread('cargo.jpg');
Cargo_Gray = rgb2gray(Cargo_Color);
imshowpair(Cargo_Color, Cargo_Gray,'montage');
%  Display all the images 
Names = {'toulouse.bmp', 'Teinte.jpg', 'SpainBeach.jpg', 'oeil.jpg', ...
    'imagexx.bmp', 'imagex.bmp', 'HSVColorSpace.jpg', 'Etoiles.png', 'champs.png', 'champs.bmp', 'cargo.jpg'};
for i = 1 : 11
    Name = Names(i);
    Name = char(Name);
    image = imread(Name);
    figure;
    imshow(image);
end
close all;


%%  Question 2 :
%  min : 0, black; max : 1, white, in double type
clear all;
clc;
image = zeros(100, 256);
for i = 1 : 100
    image(i,:) = 0:255;
end
for i = 41 : 60 
    image(i,:) = 100*ones(1,256);
end
imshow(image/256);


%% Question 3 :
clear all;
clc;
Stripe ={[], [], [],[]};
% T : the variable width
T = [2, 5 , 1, 2];
for i = 1 : length(T)
    W = 255*ones(100, T(i));
    B = 0*ones(100,T(i));
    N = floor(100/(2*T(i)));
    BW = [B, W];
    for j = 1 : N 
    Stripe{i} = [cell2mat(Stripe(i)), BW];
    end
    Stripe{i} = [cell2mat(Stripe(i)), BW(:,1:100-2*T(i)*N)];
end
figure;
subplot(2,2,1);
imshow(cell2mat(Stripe(1))/256);

subplot(2,2,2);
imshow(cell2mat(Stripe(2))/256);

subplot(2,2,3);
imshow(cell2mat(Stripe(3))/256);

subplot(2,2,4);
imshow(cell2mat(Stripe(4))'/256);


%% Question 4:
clear all;
clc;
Names = {'Teinte.jpg', 'oeil.jpg', 'cargo.jpg'};
for i = 1 : 3
    Name = Names(i);
    Name = char(Name);
    image = imread(Name);
    Red = image(:,:,1);
    Green = image(:,:,2);
    Blue = image(:,:,3);
    figure;
    subplot(2,2,1);
    imshow(Name);
    title('Image couleur');
    subplot(2,2,2);
    imshow(Red);
    title('Composante Rouge');
    subplot(2,2,3);
    imshow(Green);
    title('Composante Verte');
    subplot(2,2,4);
    imshow(Blue);
    title('Composante Bleue');
end
 

%% Question 5 :
clear all;
clc;
Flag = zeros(400,600,3);
% Blue
Flag(:,1:200,3) = 255;
% White
Flag(:,201:400,1) = 255;
Flag(:,201:400,2) = 255;
Flag(:,201:400,3) = 255;
% Red
Flag(:,401:600,1) = 255;
Flag = uint8(Flag);

figure;
subplot(2,2,1);
imshow(Flag(:,:,1), []);
title('Composante Rouge');

subplot(2,2,2);
imshow(Flag(:,:,2), []);
title('Composante Verte');

subplot(2,2,3);
imshow(Flag(:,:,3), []);
title('Composante Bleue');

subplot(2,2,4);
imshow(Flag, []);
title('Drapeau Fran?ais');


%% Question 6 :
clear all;
clc;
% Several kinds of red
R1 = zeros(100,100,3);
R1(:,:,1) = 255;
R1(:,:,2) = 0;
R1(:,:,3) = 0;

R2 = zeros(100,100,3);
R2(:,:,1) = 224;
R2(:,:,2) = 2;
R2(:,:,3) = 2;

R3 = zeros(100,100,3);
R3(:,:,1) = 165;
R3(:,:,2) = 2;
R3(:,:,3) = 2;

R4 = zeros(100,100,3);
R4(:,:,1) = 255;
R4(:,:,2) = 56;
R4(:,:,3) = 65;

R5 = zeros(100,100,3);
R5(:,:,1) = 220;
R5(:,:,2) = 20;
R5(:,:,3) = 20;

R6 = zeros(100,100,3);
R6(:,:,1) = 255;
R6(:,:,2) = 30;
R6(:,:,3) = 30;

figure;
subplot(2,3,1);
imshow(R1/256);
title('(255, 0, 0)');

subplot(2,3,2);
imshow(R2/256);
title('(224, 2, 2)');

subplot(2,3,3);
imshow(R3/256);
title('(165, 2, 2)');

subplot(2,3,4);
imshow(R4/256);
title('(255, 56, 65)');

subplot(2,3,5);
imshow(R5/256);
title('(220, 20, 20)');

subplot(2,3,6);
imshow(R6/256);
title('(255, 30, 30)');

% HSV
clear all;
clc;
RGB = imread('HSVColorSpace.jpg');
HSV = rgb2hsv(RGB);
figure;
subplot(1,2,1);
imshow(RGB);
title('RGB');

subplot(1,2,2);
imshow(HSV, []);
title('HSV');

% Gray 
Gray = rgb2gray(RGB);
figure;
subplot(1,2,1);
imshow(RGB);
title('RGB');

subplot(1,2,2);
imshow(Gray, []);
title('Gray');


%% Question 7 :
%  rgb2gray converts RGB values to grayscale values by forming a weighted sum of the R, G, and B components:
%  0.2989 * R + 0.5870 * G + 0.1140 * B 


%% Question 8 : 
clear all;
clc;
Lena = imread('Lena.jpg');

% Method 1 : Histogram equalization in each canal
R = Lena(:,:,1);
G = Lena(:,:,2);
B = Lena(:,:,3);

R_eq = histeq(R);
G_eq = histeq(G);
B_eq = histeq(B);

Lena_eq1 = zeros(size(Lena));
Lena_eq1(:,:,1) = R_eq;
Lena_eq1(:,:,2) = G_eq;
Lena_eq1(:,:,3) = B_eq;

Lena_eq1 = uint8(Lena_eq1);


% Method 2 : Histogram equalization in the canal of luminance in the HSV
% color space
HSV = rgb2hsv(Lena);
V = HSV(:,:,3);
V_eq = histeq(V);
HSV_eq = HSV;
HSV_eq(:,:,3) = V_eq;
Lena_eq2 = hsv2rgb(HSV_eq);

figure;
subplot(1,3,1);
imshow(Lena);
title('Lena');

subplot(1,3,2);
imshow(Lena_eq1);
title('M?thode 1');

subplot(1,3,3);
imshow(Lena_eq2);
title('M?thode 2');


%% Question 9 : 
clear all;
clc;
imagex = imread('imagex.bmp');
imshow(imagex);
imhist(imagex);

imagex_eq = histeq(imagex);
imshow(imagex_eq);
imhist(imagex_eq);


imagexx = imread('imagexx.bmp');
imshow(imagexx);
imhist(imagexx);

figure;
imagexx_eq = histeq(imagexx);
imshow(imagexx_eq);
imhist(imagex_eq);


%% Question 10 :
clear all;
clc;
SpainBeach = imread('SpainBeach.jpg');
figure;
imshow(SpainBeach);
% Turn to the HSV color space
HSV = rgb2hsv(SpainBeach);
% Get the Color of the beach, use the data cursor
H = HSV(:,:,1);
figure;
imshow(H); % 0.03 - 0.06
% the coordinates of the beach
[row, col] = find(H < 0.06 & H > 0.03);

Beach = zeros(size(SpainBeach));
for i = 1 : length(row)
    Beach(row(i), col(i), :) = SpainBeach(row(i), col(i), :);
end
Beach = uint8(Beach);
figure;
imshow(Beach)

% Mathematical morphology to improve the result
Gray = rgb2gray(Beach);
figure, imshow(Gray, []);

se = strel('disk',2);
MM = imopen(Gray, se);
figure, imshow(MM, []);


% Turn to the RGB color space 

% need to modify
img = MM;
filler = zeros(size(img),'uint8');
rgbImage = cat(3,img,filler,filler);
figure, imshow(rgbImage);

Beach_new = gray2rgb('MM.jpg', 'SpainBeach.jpg');
figure, imshow(Beach_new, []);


%% Question 11 :
% Need to run Question 3 to get the stripes
% Blur on Stripes
Stripe_1 = cell2mat(Stripe(1));
Stripe_2 = cell2mat(Stripe(2));
Stripe_3 = cell2mat(Stripe(3));
Stripe_4 = cell2mat(Stripe(4))';

h = fspecial('motion', 50, 45);
Blur_1 = imfilter(Stripe_1, h);
Blur_2 = imfilter(Stripe_2, h);
Blur_3 = imfilter(Stripe_3, h);
Blur_4 = imfilter(Stripe_4, h);

figure;
subplot(2,4,1);
imshow(Stripe_1/256);
subplot(2,4,2);
imshow(Stripe_2/256);
subplot(2,4,3);
imshow(Stripe_3/256);
subplot(2,4,4);
imshow(Stripe_4/256);

subplot(2,4,5);
imshow(Blur_1/256);
subplot(2,4,6);
imshow(Blur_2/256);
subplot(2,4,7);
imshow(Blur_3/256);
subplot(2,4,8);
imshow(Blur_4/256);

% Blur on cargo
Cargo = imread('cargo.jpg');
Blur_Cargo = imfilter(Cargo, h);
figure;
subplot(1,2,1);
imshow(Cargo);
subplot(1,2,2);
imshow(Blur_Cargo);

% Edge detection on Stripes
h2= fspecial('laplacian');
Edge_1 = imfilter(Stripe_1, h2);
Edge_2 = imfilter(Stripe_2, h2);
Edge_3 = imfilter(Stripe_3, h2);
Edge_4 = imfilter(Stripe_4, h2);

Edge_Cargo = imfilter(Cargo, h2);

figure;
subplot(2,4,1);
imshow(Stripe_1/256);
subplot(2,4,2);
imshow(Stripe_2/256);
subplot(2,4,3);
imshow(Stripe_3/256);
subplot(2,4,4);
imshow(Stripe_4/256);

subplot(2,4,5);
imshow(Edge_1/256);
subplot(2,4,6);
imshow(Edge_2/256);
subplot(2,4,7);
imshow(Edge_3/256);
subplot(2,4,8);
imshow(Edge_4/256);

figure;
subplot(1,2,1);
imshow(Cargo);
subplot(1,2,2);
imshow(Edge_Cargo);


%% Question 12 :
clear all;
clc;
Etoiles = imread('Etoiles.png');
figure, imshow(Etoiles);
% find the location of the stars
HSV = rgb2hsv(Etoiles);
V = HSV(:,:,3);
[row, col] = find(V > 0.98);
Cinq = zeros(size(Etoiles));
for i = 1 : length(row)
    Cinq(row(i), col(i), :) = Etoiles(row(i), col(i), :);
end
Cinq = uint8(Cinq);
figure, imshow(Cinq);

% Use the median filter to reduce the luminance of the stars in order to
% find the five most bright stars
h = fspecial('average', 15);
Etoiles_Moy = imfilter(Etoiles, h);

HSV_M = rgb2hsv(Etoiles_Moy);
V_M = HSV_M(:,:,3);
[row_M, col_M] = find(V_M > 0.98);
Cinq_M = zeros(size(Etoiles_Moy));
for i = 1 : length(row_M)
    Cinq_M(row_M(i), col_M(i), :) = Etoiles_Moy(row_M(i), col_M(i), :);
end
Cinq_M = uint8(Cinq_M);
figure, imshow(Cinq_M);


%% Question 13 :
% Need to run Question 3 to get the stripes
Stripe_1 = cell2mat(Stripe(1))/256;
Stripe_2 = cell2mat(Stripe(2))/256;
Stripe_3 = cell2mat(Stripe(3))/256;
Stripe_4 = cell2mat(Stripe(4))'/256;
% Fourier Transform 
FT_1 = fft2(Stripe_1);
FT_2 = fft2(Stripe_2);
FT_3 = fft2(Stripe_3);
FT_4 = fft2(Stripe_4);

% Comparison of the Stripe_1 and Stripe_2 
figure;
subplot(2,2,1);
imshow(Stripe_1);

subplot(2,2,2);
imshow(Stripe_2);

subplot(2,2,3);
imshow(log(abs(fftshift(FT_1))));

subplot(2,2,4);
imshow(log(abs(fftshift(FT_2))));

% % Comparison of the Stripe_1 and Stripe_4 
figure;
subplot(2,2,1);
imshow(Stripe_1);

subplot(2,2,2);
imshow(Stripe_4);

subplot(2,2,3);
imshow(log(abs(fftshift(FT_1))));

subplot(2,2,4);
imshow(log(abs(fftshift(FT_4))));


%% Question 14 :
clear all;
clc;
Lena = imread('Lena.jpg');
h = fspecial('average', 7);
Blur = imfilter(Lena, h);

figure;
subplot(1,2,1);
imshow(Lena);
subplot(1,2,2);
imshow(Blur);

G_1 = rgb2gray(Lena);
G_1 = im2double(G_1);
FT_1 = fft2(G_1);

G_2 = rgb2gray(Blur);
G_2 = im2double(G_2);
FT_2 = fft2(G_2); 

figure;
subplot(1,2,1);
imshow(log(abs(fftshift(FT_1))));
subplot(1,2,2);
imshow(log(abs(fftshift(FT_2))));

% Denoise in the frequency domain
clear all;
clc;
Fille = imread('Fille.jpg');
% turn to gray
Fille = rgb2gray(Fille);
Fille_Noise = imnoise(Fille, 'speckle',0.01); 
figure;
subplot(1,2,1);
imshow(Fille);
subplot(1,2,2);
imshow(Fille_Noise);

% Turn to double type 
% FFT compare 
Fille = im2double(Fille);
Fille_Noise = im2double(Fille_Noise);

FT = fft2(Fille);
FT_Noise = fft2(Fille_Noise);

% Try to denoise

centre = floor(size(FT_Noise)/2) + [1, 1];

M = size(FT_Noise, 1);
N = size(FT_Noise, 2);

FFT = fftshift(FT_Noise);
De_FT = FFT;
for u = 1 : M
   for v = 1 : N
    D = sqrt((u - centre(1))^2 + (v - centre(2))^2);
    if D > 30
        De_FT(u,v) = 0;
    end
   end
end

% Show the image after the process of denoise
De_FT = ifftshift(De_FT);
Denoise = ifft2(De_FT);
figure;
imshow(Denoise);

% Compare the spectrum of the image with noise and the image after the process
% of the denoise
figure;
subplot(1,2,1);
imshow(log(abs(fftshift(FT_Noise))), []);
subplot(1,2,2);
imshow(log(abs(fftshift(De_FT))),[]);


%% Question 15 : 

clear all;
clc;
Champs = imread('champs.bmp');
figure, imshow(Champs);
Gray_Champs =rgb2gray(Champs);
Gray_Champs = im2double(Gray_Champs);
FT_Champs = fftshift(fft2(Gray_Champs));
figure, imshow(log(abs(FT_Champs)),[]);

orientation= 330;
wavelength = 5;
gabor = imgaborfilt(Gray_Champs,wavelength,orientation);
figure, imshow(gabor,[]);

FT_gabor = fftshift(fft2(gabor));
figure, imshow(log(abs((FT_gabor))),[]);

figure;
subplot(1,2,1);
imshow(log(abs(FT_Champs)),[]);
subplot(1,2,2);
imshow(log(abs((FT_gabor))),[]);

[row, col] = find(gabor > 2.5);
bw = zeros(size(gabor));
for i = 1 : length(row)
    bw(row(i), col(i)) = 1;
end
figure, imshow(bw);

% MM  close--open
se = strel('disk',10);
closebw = imclose(bw, se);
figure, imshow(closebw);
openbw = imopen(closebw, se);
figure, imshow(openbw);

figure;
subplot(1,2,1);
imshow(closebw);
subplot(1,2,2);
imshow(openbw);
% rebuild the field extracted 
field = zeros(size(Champs));
[u, v] = find(openbw ==1);
for i = 1 : length(u)
    field(u(i), v(i), :) = Champs(u(i), v(i), :);
end
field = uint8(field);
figure, imshow(field);


%% Question 16 : 
% See in the report


%% Question 17 & 18 :
clear all;
clc;
T = 3; 
Toulouse = imread('toulouse.bmp');
h = fspecial('average',2*T+1);
Toulouse_blurred = imfilter(Toulouse,h);
FT_Toulouse = fftshift(fft2(Toulouse));
FT_Toulouse_blurred = fftshift(fft2(Toulouse_blurred));

N = size(Toulouse,2);
u = 0 : N;
Hu = (1/(2*T+1))*sin(2*pi*u*(T+1/2)/N)./sin(pi*u/N);
Sinc = sin(2*pi*u*(T+1/2)/N)./(2*pi*u*(T+1/2)/N);

% Plotting of H and cardinal sinus
figure;
hold on
plot(u,Hu);
plot(u,Sinc);
grid on;
hold off
legend('H(u)','sinc(u)');

% Use the black stripe to estimate T 
figure;
subplot(1,2,1); imshow(Toulouse);
subplot(1,2,2); imshow(Toulouse_blurred);
figure;
subplot(1,2,1); imshow(log(abs(FT_Toulouse)), []);
subplot(1,2,2); imshow(log(abs(FT_Toulouse_blurred)), []);


%% Question 19 & 20 :
clear all;
clc; 
% Turn to the double type
image = im2double(imread('toulouse.bmp')); 
filter = fspecial('average', 7);

SeuilMax = 11; % what does it mean
TailleImage =size(image); 
TailleFiltre= size(filter);
hh = zeros(TailleImage);
% the center of the image
centre = [1 1] + floor(TailleImage/2); 
% the center of the filter
ext = (TailleFiltre -[1 1])/2;    
% select the lignes and colomns in the image at the same size of filter
ligs = centre(1) + [-ext(1):ext(1)];    
cols = centre(2) + [-ext(2):ext(2)];
% Median filter
h = ones(TailleFiltre)/prod(TailleFiltre); 
hh(ligs,cols) = h;
% Transfer the parts of the filter to the corners 
hh = ifftshift(hh); 

H = fft2(hh);

ind = find(abs(H)<(1/SeuilMax));
H(ind) = (1/SeuilMax)*exp(j*angle(H(ind))); 

G = ones(size(H))./H;

% Case without noise
image_blurred = imfilter(image,filter);
FT_image_blurred = fft2(image_blurred);
image_deblurred = ifft2(G.*FT_image_blurred);

figure
subplot(1,2,1)
imshow(image_blurred)

subplot(1,2,2)
imshow(image_deblurred )

% Case with noise

mean = 0;
variance = 0.001;
image_blurred_noise= imnoise(image_blurred,'gaussian', mean, variance);
Image_Blurred_Noise= fft2(image_blurred_noise);
image_deblurred_noise = ifft2(G.*Image_Blurred_Noise);
figure
subplot(1,2,1)
imshow(image_blurred_noise)

subplot(1,2,2)
imshow(image_deblurred_noise)


%% Question 21 : 
% Use the same figure Toulouse in the Question 19 & 20

% Calculate the SNR
SNR = variance / var(image(:));
image_wiener = deconvwnr(image_blurred_noise,filter,SNR);
figure;
subplot(1,2,1);
imshow(image_blurred_noise);

subplot(1,2,2);
imshow(image_wiener);

% Case without information about SNR

image_wiener_sanSNR = deconvwnr(image_blurred_noise,filter);
figure;
subplot(1,2,1);
imshow(image_blurred_noise);

subplot(1,2,2);
imshow(image_wiener_sanSNR);